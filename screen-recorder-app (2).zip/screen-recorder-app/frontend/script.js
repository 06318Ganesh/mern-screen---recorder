let mediaRecorder;
let recordedChunks = [];

const startBtn = document.getElementById("startBtn");
const stopBtn = document.getElementById("stopBtn");
const preview = document.getElementById("preview");

startBtn.onclick = async () => {
  const stream = await navigator.mediaDevices.getDisplayMedia({ video: true, audio: true });
  mediaRecorder = new MediaRecorder(stream);
  
  mediaRecorder.ondataavailable = e => {
    if (e.data.size > 0) recordedChunks.push(e.data);
  };
  
  mediaRecorder.onstop = async () => {
    const blob = new Blob(recordedChunks, { type: "video/webm" });
    recordedChunks = [];
    preview.src = URL.createObjectURL(blob);

    const formData = new FormData();
    formData.append("video", blob, "recording.webm");

    await fetch("http://localhost:5000/upload", { method: "POST", body: formData });
    alert("Video uploaded successfully!");
  };

  mediaRecorder.start();
  startBtn.disabled = true;
  stopBtn.disabled = false;
};

stopBtn.onclick = () => {
  mediaRecorder.stop();
  startBtn.disabled = false;
  stopBtn.disabled = true;
};
