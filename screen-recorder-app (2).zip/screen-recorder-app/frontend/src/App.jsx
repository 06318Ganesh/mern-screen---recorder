import React, { useState, useRef, useEffect } from 'react';

const BACKEND = import.meta.env.VITE_BACKEND_URL || 'http://localhost:4000';

function formatTime(sec) {
  const mm = String(Math.floor(sec / 60)).padStart(2, '0');
  const ss = String(sec % 60).padStart(2, '0');
  return `${mm}:${ss}`;
}

export default function App() {
  const [page, setPage] = useState('record');
  return (
    <div style={{ fontFamily: 'system-ui, sans-serif', padding: 18 }}>
      <header style={{ display: 'flex', gap: 12, alignItems: 'center', marginBottom: 16 }}>
        <h2 style={{ margin: 0 }}>Screen Recorder</h2>
        <nav>
          <button onClick={() => setPage('record')}>Record</button>{' '}
          <button onClick={() => setPage('list')}>Recordings</button>
        </nav>
      </header>
      {page === 'record' ? <Recorder backend={BACKEND} /> : <RecordingsList backend={BACKEND} />}
    </div>
  );
}

function Recorder({ backend }) {
  const videoRef = useRef(null);
  const previewRef = useRef(null);
  const mediaRecorderRef = useRef(null);
  const chunksRef = useRef([]);
  const timerRef = useRef(null);

  const [isRecording, setIsRecording] = useState(false);
  const [seconds, setSeconds] = useState(0);
  const [uploadStatus, setUploadStatus] = useState(null);
  const [error, setError] = useState(null);

  const MAX_SECONDS = 180;

  useEffect(() => {
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
      if (previewRef.current && previewRef.current.src) {
        URL.revokeObjectURL(previewRef.current.src);
      }
    };
  }, []);

  async function startRecording() {
    setError(null);
    setUploadStatus(null);
    try {
      const displayStream = await navigator.mediaDevices.getDisplayMedia({ video: true });
      const audioStream = await navigator.mediaDevices.getUserMedia({ audio: true });

      const combined = new MediaStream();
      displayStream.getVideoTracks().forEach((t) => combined.addTrack(t));
      audioStream.getAudioTracks().forEach((t) => combined.addTrack(t));

      if (videoRef.current) {
        videoRef.current.srcObject = combined;
        videoRef.current.muted = true;
        videoRef.current.play().catch(() => {});
      }

      const options = { mimeType: 'video/webm; codecs=vp9,opus' };
      const mediaRecorder = new MediaRecorder(combined, options);
      mediaRecorderRef.current = mediaRecorder;
      chunksRef.current = [];

      mediaRecorder.ondataavailable = (e) => {
        if (e.data && e.data.size > 0) chunksRef.current.push(e.data);
      };

      mediaRecorder.onstop = () => {
        combined.getTracks().forEach((t) => t.stop());
        const blob = new Blob(chunksRef.current, { type: 'video/webm' });
        const url = URL.createObjectURL(blob);
        if (previewRef.current) {
          previewRef.current.src = url;
        }
        setIsRecording(false);
        setSeconds(0);
        if (timerRef.current) clearInterval(timerRef.current);
      };

      mediaRecorder.start(1000);
      setIsRecording(true);
      setSeconds(0);

      timerRef.current = setInterval(() => {
        setSeconds((s) => {
          if (s + 1 >= MAX_SECONDS) {
            stopRecording();
            return MAX_SECONDS;
          }
          return s + 1;
        });
      }, 1000);
    } catch (err) {
      console.error(err);
      setError('Permission denied or no supported media devices. Use Chrome and allow screen + microphone.');
    }
  }

  function stopRecording() {
    try {
      if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
        mediaRecorderRef.current.stop();
      }
    } catch (e) {
      console.error('stop error', e);
    }
  }

  function downloadRecording() {
    if (!chunksRef.current.length) return;
    const blob = new Blob(chunksRef.current, { type: 'video/webm' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = `recording-${Date.now()}.webm`;
    document.body.appendChild(a);
    a.click();
    a.remove();
  }

  async function uploadRecording() {
    setUploadStatus(null);
    setError(null);
    if (!chunksRef.current.length) {
      setError('No recording to upload.');
      return;
    }
    const blob = new Blob(chunksRef.current, { type: 'video/webm' });
    const fd = new FormData();
    fd.append('file', blob, `recording-${Date.now()}.webm`);
    fd.append('title', `Recording ${new Date().toISOString()}`);
    try {
      const res = await fetch(`${backend}/api/recordings`, {
        method: 'POST',
        body: fd,
      });
      if (!res.ok) {
        const txt = await res.text();
        throw new Error(txt || 'Upload failed');
      }
      setUploadStatus('Upload successful!');
      chunksRef.current = [];
      if (previewRef.current) previewRef.current.src = '';
    } catch (err) {
      console.error(err);
      setError('Upload failed: ' + (err.message || ''));
    }
  }

  return (
    <div>
      <section style={{ marginBottom: 20 }}>
        <h3>Record (Chrome required for tab recording with mic)</h3>
        <div>
          <video ref={videoRef} style={{ width: 480, maxWidth: '100%', border: '1px solid #ddd' }} autoPlay />
        </div>
        <div style={{ marginTop: 8 }}>
          {!isRecording ? (
            <button onClick={startRecording}>Start</button>
          ) : (
            <button onClick={stopRecording}>Stop</button>
          )}{' '}
          <span style={{ marginLeft: 12 }}>Timer: {formatTime(seconds)}</span>{' '}
          <small style={{ marginLeft: 8, color: '#666' }}>(Max 03:00)</small>
        </div>
        {error && <div style={{ color: 'red', marginTop: 8 }}>{error}</div>}
      </section>

      <section>
        <h3>Preview</h3>
        <video ref={previewRef} controls style={{ width: 480, maxWidth: '100%', border: '1px solid #ddd' }} />
        <div style={{ marginTop: 8 }}>
          <button onClick={downloadRecording} disabled={!chunksRef.current.length}>Download</button>{' '}
          <button onClick={uploadRecording} disabled={!chunksRef.current.length}>Upload</button>
        </div>
        {uploadStatus && <div style={{ color: 'green', marginTop: 8 }}>{uploadStatus}</div>}
      </section>
    </div>
  );
}

function RecordingsList({ backend }) {
  const [list, setList] = useState([]);
  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState(null);

  async function fetchList() {
    setLoading(true);
    setErr(null);
    try {
      const res = await fetch(`${backend}/api/recordings`);
      if (!res.ok) throw new Error('Failed to load');
      const data = await res.json();
      setList(data);
    } catch (e) {
      console.error(e);
      setErr('Failed to fetch recordings');
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    fetchList();
  }, []);

  return (
    <div>
      <h3>Uploaded Recordings</h3>
      <button onClick={fetchList} disabled={loading}>Refresh</button>
      {loading && <div>Loading…</div>}
      {err && <div style={{ color: 'red' }}>{err}</div>}
      <div style={{ marginTop: 12 }}>
        {list.length === 0 && <div>No recordings yet.</div>}
        {list.map((r) => (
          <RecordingRow key={r.id} rec={r} />
        ))}
      </div>
    </div>
  );
}

function RecordingRow({ rec }) {
  const [playing, setPlaying] = useState(false);
  const videoRef = useRef(null);

  function togglePlay() {
    if (!videoRef.current) return;
    if (videoRef.current.paused) {
      videoRef.current.play();
      setPlaying(true);
    } else {
      videoRef.current.pause();
      setPlaying(false);
    }
  }

  return (
    <div style={{ border: '1px solid #eee', padding: 12, marginBottom: 8 }}>
      <div style={{ display: 'flex', gap: 12, alignItems: 'center' }}>
        <div style={{ flex: 1 }}>
          <div style={{ fontWeight: 600 }}>{rec.title || rec.originalname}</div>
          <div style={{ fontSize: 13, color: '#555' }}>{(rec.size / (1024 * 1024)).toFixed(2)} MB — {new Date(rec.createdAt).toLocaleString()}</div>
        </div>
        <div>
          <button onClick={togglePlay}>{playing ? 'Pause' : 'Play'}</button>{' '}
          <a href={rec.url} download target="_blank" rel="noreferrer"><button>Download</button></a>
        </div>
      </div>
      <div style={{ marginTop: 8 }}>
        <video ref={videoRef} src={rec.url} controls style={{ width: '100%', maxWidth: 720 }} />
      </div>
    </div>
  );
}
