
# Screen Recorder App (MERN-style take-home)

This repo contains a simple Screen Recorder frontend (React + Vite) and a Node/Express backend (SQLite) to accept uploads.

## Features
- Record current tab (Chrome) + microphone.
- 3 minute limit.
- Preview, download, upload recording.
- List uploaded recordings with inline play.

## Run locally

### Backend
```bash
cd backend
npm install
mkdir uploads
npm run dev   # requires nodemon or use npm start
```

### Frontend
```bash
cd frontend
npm install
# set VITE_BACKEND_URL if backend isn't at http://localhost:4000
npm run dev
```

Open the frontend (Vite usually on http://localhost:5173) and test.

## Notes
- Chrome recommended for tab recording.
- For production, use S3 and Postgres; SQLite and local uploads are for demo only.
